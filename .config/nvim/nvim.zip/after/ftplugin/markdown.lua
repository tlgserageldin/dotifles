vim.opt_local.spell = true
vim.opt_local.list = true
vim.opt_local.wrap = true
